const mongoose = require('mongoose')
const Schema = mongoose.Schema

//Create Schema
const ModelSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    number: {
        type: Number,
        required: true
    },
    createdBy: {
        type: String,
        required: true
    }
})

module.exports = Item = mongoose.model('contact', ModelSchema)
