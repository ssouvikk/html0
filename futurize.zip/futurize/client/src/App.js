import React, { Component } from 'react'
import './App.css';
import Register from './pages/Register';
import { BrowserRouter } from 'react-router-dom'
import { Redirect, Route, Switch } from 'react-router'
import Login from './pages/Login';
import NotFound from './pages/NotFound';
import { loadUser } from './actions/auth'
import { connect } from 'react-redux'
import HomePage from './pages/HomePage';
import Add from './pages/Add';
import NavBar from './components/NavBar/NavBar';

class App extends Component {

	componentDidMount = () => {
		this.props.loadUser()
	}

	render() {
		return (
			<div className="app">
				<BrowserRouter>
					<NavBar />
					<div className="container">
						<Switch>
							<Route exact path="/" render={() => <Redirect to="/register" />} />
							<Route exact path="/dashboard" component={HomePage} />
							<Route exact path="/login" component={Login} />
							<Route exact path="/register" component={Register} />
							<Route exact path="/add" component={Add} />
							<Route path="*" component={NotFound} />
						</Switch>
					</div>
				</BrowserRouter>
			</div>
		);
	}
}

const mapStatesToProps = (globalStore) => ({
	globalStore: globalStore.auth
})

export default connect(mapStatesToProps, { loadUser })(App)