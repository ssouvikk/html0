import { GET_CONTACT, ADD_CONTACT, DELETE_CONTACT } from '../actions/types'

const initialState = {
    contact: []
}

const contactReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_CONTACT:
            return { ...state, contact: action.payload }

        case ADD_CONTACT:
            return { ...state, contact: [...state.contact, action.payload] }

        case DELETE_CONTACT:
            return { ...state, contact: state.contact.filter(contact => contact._id !== action.payload) }

        default:
            return state
    }
}

export default contactReducer