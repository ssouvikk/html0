import { Redirect } from 'react-router'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { register } from '../actions/auth'

class Register extends Component {
    state = {
        name: '',
        email: '',
        password: '',
        err: null
    }

    handleChange = (e) => this.setState({ [e.target.name]: e.target.value })

    handleSubmit = e => {
        e.preventDefault()
        const { name, email, password } = this.state
        this.props.register({ name, email, password })
    }

    render() {
        const { error } = this.props
        if (this.props.auth.isAuthenticated) {
            return <Redirect to={`/${localStorage.getItem('lastPage') ? localStorage.getItem('lastPage') : "dashboard"}`} />
        }
        return (
            <div>
                <h1 className="text-center">Register</h1>
                {error.status && error.msg !== 'no token, authorisation denied' ? (
                    <div className="alert alert-danger" role="alert">
                        {error.msg}
                    </div>
                ) : ''}
                <form onSubmit={this.handleSubmit}>
                    <div className="mb-3">
                        <label className="form-label">Name </label>
                        <input required value={this.state.name} onChange={this.handleChange} type="text" name="name" className="form-control" />
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Email address</label>
                        <input required value={this.state.email} onChange={this.handleChange} type="email" name="email" className="form-control" />
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Password</label>
                        <input required value={this.state.password} onChange={this.handleChange} type="password" name="password" className="form-control" />
                    </div>
                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
            </div>
        )
    }
}


const mapStatesToProps = (globalStore) => ({
    auth: globalStore.auth,
    error: globalStore.error
})

export default connect(mapStatesToProps, { register })(Register)