import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import { connect } from 'react-redux'
import { Redirect } from 'react-router'
import { logout2 } from '../actions/auth'
import { getContact, deleteContact } from '../actions/contact'


class HomePage extends Component {

    componentDidMount = () => this.props.getContact()

    handleLogOut = () => this.props.logout2()

    handleDelete = (id) => this.props.deleteContact(id)

    render() {
        localStorage.setItem('lastPage', 'dashboard')
        const { contacts, auth } = this.props
        if (!auth.isAuthenticated) {
            return <Redirect to="/login" />
        }
        return (
            <div>
                <div className={`m-4`}>
                    <Link style={{ float: "right" }} className="btn btn-success" to="/add" >Add </Link>
                    <h1>Your Contact(s) List </h1>
                </div>
                {contacts.map(contact => (
                    <div key={contact._id} className="row m-2">
                        <div className="col">
                            <Link onClick={() => this.handleDelete(contact._id)} to="#" className="m-2 btn btn-danger btn-sm" tabIndex="-1" role="button">Delete</Link>
                            <Link to={`/edit/contact._id`} className="m-2 btn btn-primary btn-sm" tabIndex="-1" role="button">Edit</Link>
                        </div>
                        <div className="col"><h4>  {contact.name}</h4></div>
                        <div className="col"><p> {contact.number}</p> </div>
                    </div>
                ))}
            </div>
        )
    }
}


const mapStatesToProps = (globalStore) => ({
    auth: globalStore.auth,
    contacts: globalStore.contact.contact
})

export default connect(mapStatesToProps, { logout2, getContact, deleteContact })(HomePage)