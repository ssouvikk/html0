import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Redirect } from 'react-router'
import { addContact } from '../actions/contact'


class Add extends Component {
    state = {
        name: '', number: ''
    }

    handleChage = (e) => {
        this.setState({ [e.target.name]: e.target.value })
    }

    handleSubmit = (e) => {
        e.preventDefault()
        const val = {
            name: this.state.name,
            number: this.state.number,
        }
        this.props.addContact(val)
        this.props.history.push('/dashboard')
    }

    render() {
        localStorage.setItem('lastPage', 'add')
        if (!this.props.auth.isAuthenticated) {
            return <Redirect to="/login" />
        }
        return (
            <div>
                <h1>Add Contact </h1>
                <form onSubmit={this.handleSubmit}>
                    <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label">Name</label>
                        <input required value={this.state.name} onChange={this.handleChage} name="name" type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="exampleInputPassword1" className="form-label">Number </label>
                        <input required value={this.state.number} onChange={this.handleChage} name="number" type="number" className="form-control" id="exampleInputPassword1" />
                    </div>
                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
            </div>
        )
    }
}


const mapStatesToProps = (globalStore) => ({
    auth: globalStore.auth
})

export default connect(mapStatesToProps, { addContact })(Add)