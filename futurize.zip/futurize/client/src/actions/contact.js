import { GET_CONTACT, ADD_CONTACT, DELETE_CONTACT } from './types'
import axios from 'axios'
import { tokenConfig } from './auth'
import { loadErrors, clearErrors } from './error'

// export const loadErrors = (msg, status, id = null) =>{
export const getContact = () => (dispatch, getState) => {
    axios.get('/api/contacts', tokenConfig(getState)).then(res => {
        dispatch(clearErrors())
        dispatch({
            type: GET_CONTACT,
            payload: res.data
        })
    }).catch((err) => {
        dispatch(loadErrors(err.response))
    })
}

export const deleteContact = id => (dispatch, getState) => {
    axios.delete(`/api/contacts/${id}`, tokenConfig(getState))
        .then(res => {
            dispatch({
                type: DELETE_CONTACT,
                payload: id
            })
        }).catch((err) => {
            dispatch(loadErrors(err.response))
        })

}

export const addContact = contactData => (dispatch, getState) => {
    axios.post('/api/contacts', contactData, tokenConfig(getState))
        .then(res => dispatch({
            type: ADD_CONTACT,
            payload: res.data
        }))
        .catch((err) => {
            dispatch(loadErrors(err.response))
        })
}