export const REGISTER_SUCCESS = 'REGISTER_SUCCESS'
export const REGISTER_FAIL = 'REGISTER_FAIL'

export const LOAD_ERROR = 'LOAD_ERROR'
export const CLEAR_ERROR = 'CLEAR_ERROR'

export const USER_LOADING = 'USER_LOADING'
export const USER_LOAD_SUCCESS = 'USER_LOAD_SUCCESS'
export const USER_LOAD_FAIL = 'USER_LOAD_FAIL'

export const LOGIN_SUCCESS = 'LOGIN_SUCCESS'
export const LOGIN_FAIL = 'LOGIN_FAIL'

export const LOG_OUT = 'LOG_OUT'

export const GET_CONTACT = 'GET_CONTACT'
export const ADD_CONTACT = 'ADD_CONTACT'
export const DELETE_CONTACT = 'DELETE_CONTACT'