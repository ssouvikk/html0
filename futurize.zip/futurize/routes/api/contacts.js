const express = require('express')
const router = express.Router()
const auth = require('../../middleware/auth')
const Contact = require('../../models/Contact')

// @route GET api/contacts
// @desc Get all contacts
// @access public
router.get('/', auth, (req, res) => {
    Contact.find({ createdBy: req.user._id })
        // .sort({ data: -1 })
        .then(contacts => res.json(contacts))
})

// @route POST api/contacts
// @desc Post contact
// @access private
router.post('/', auth, (req, res) => {
    const newContact = new Item({
        name: req.body.name,
        number: req.body.number,
        createdBy: req.user._id
    })
    newContact.save()
        .then(contact => res.status(201).json(contact))
})

// @route DELETE api/contacts
// @desc delete contact
// @access private
router.delete('/:id', auth, (req, res) => {
    Contact.findById(req.params.id)
        .then(contact => contact.remove().then(() => res.json({ success: true })))
        .catch(err => res.status(404).json({ success: false }))
})

module.exports = router