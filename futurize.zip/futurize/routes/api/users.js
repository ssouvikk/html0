const express = require('express')
const bcrypt = require('bcrypt')
const router = express.Router()
const jwt = require('jsonwebtoken')

const User = require('../../models/User')
const config = require('config')

// @route GET api/users
// @desc register new user
// @access public
router.post('/', (req, res) => {
    const { name, email, password } = req.body
    if (!name || !email || !password) {
        return res.status(400).json({ msg: 'plz enter all fields' })
    }
    User.findOne({ email })
        .then(user => {
            if (user) return res.status(400).json({ msg: 'user is already registered' })
            else {
                const newUser = new User({ name, email, password })
                bcrypt.hash(password, 10, (err, hash) => {
                    if (err) throw err
                    newUser.password = hash
                    newUser.save((err, lastUser) => {
                        if (!err) {
                            const { _id, name, email } = lastUser
                            jwt.sign(
                                { _id, name, email },
                                config.get('jwtSecret'),
                                { expiresIn: 7200 },
                                (err, token) => {
                                    if (err) throw err
                                    return res.status(201).json({
                                        token,
                                        user: { _id, name, email }
                                    })
                                }
                            )
                        }
                    })
                })
            }
        })
})

module.exports = router