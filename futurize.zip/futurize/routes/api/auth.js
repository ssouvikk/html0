const express = require('express')
const bcrypt = require('bcrypt')
const router = express.Router()
const jwt = require('jsonwebtoken')
const auth = require('../../middleware/auth')

const User = require('../../models/User')
const config = require('config')


// @route GET api/auth
// @desc login user
// @access public
router.post('/', (req, res) => {
    const { email, password } = req.body
    if (!email || !password) {
        return res.status(400).json({ msg: 'plz enter all fields' })
    }
    User.findOne({ email })
        .then(user => {
            if (!user) return res.status(400).json({ msg: 'User does not exists' })
            else {
                bcrypt.compare(password, user.password)
                    .then(isMatch => {
                        if (!isMatch) return res.status(401).json({ msg: 'invalid credential' })
                        const { _id, email, name } = user
                        jwt.sign(
                            { _id, email, name },
                            config.get('jwtSecret'),
                            { expiresIn: 3600 },
                            (err, token) => {
                                if (err) throw err
                                res.json({
                                    token,
                                    user: { _id, name, email }
                                })
                            }
                        )
                    })
            }
        })

})

// @route GET api/auth
// @desc auth user
// @access private
router.get('/user', auth, (req, res) => {
    User.findById(req.user._id)
        .select('-password')
        .then(user => res.json(user))
})


module.exports = router